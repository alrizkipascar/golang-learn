package main

import "fmt"

func helloWorld() {
    fmt.Println("Hello World!")
}